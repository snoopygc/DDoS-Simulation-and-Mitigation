'use client'
import React from 'react';
import { useState, useEffect } from 'react'
import { useSimulation } from '../contexts/SimulationContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"

interface Packet {
    id: number
    timestamp: number
    source: string
    destination: string
    protocol: string
    size: number
    flags: string
}

export default function PacketInspector() {
    const { isUnderAttack, mitigationLevel } = useSimulation()
    const [packets, setPackets] = useState<Packet[]>([])

    useEffect(() => {
        const interval = setInterval(() => {
            const newPacket: Packet = {
                id: Date.now(),
                timestamp: Date.now(),
                source: `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
                destination: '10.0.0.1',
                protocol: Math.random() > 0.5 ? 'TCP' : 'UDP',
                size: Math.floor(Math.random() * 1000) + 64,
                flags: isUnderAttack ? 'SYN' : Math.random() > 0.5 ? 'ACK' : 'PSH',
            }

            setPackets(prev => [newPacket, ...prev.slice(0, 19)])
        }, isUnderAttack ? 100 : 500)

        return () => clearInterval(interval)
    }, [isUnderAttack])

    return (
        <Card>
            <CardHeader>
                <CardTitle>Packet Inspector</CardTitle>
                <CardDescription>Real-time packet analysis</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Timestamp</TableHead>
                            <TableHead>Source</TableHead>
                            <TableHead>Destination</TableHead>
                            <TableHead>Protocol</TableHead>
                            <TableHead>Size</TableHead>
                            <TableHead>Flags</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {packets.map((packet) => (
                            <TableRow key={packet.id}>
                                <TableCell>{new Date(packet.timestamp).toLocaleTimeString()}</TableCell>
                                <TableCell>{packet.source}</TableCell>
                                <TableCell>{packet.destination}</TableCell>
                                <TableCell>{packet.protocol}</TableCell>
                                <TableCell>{packet.size}</TableCell>
                                <TableCell>{packet.flags}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    )
}

