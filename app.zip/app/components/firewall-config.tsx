import React from 'react';
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"

interface Rule {
    id: number
    source: string
    destination: string
    port: string
    action: string
}

export default function FirewallConfig() {
    const [rules, setRules] = useState<Rule[]>([
        { id: 1, source: '192.168.1.0/24', destination: 'Any', port: 'Any', action: 'Allow' },
        { id: 2, source: 'Any', destination: '10.0.0.1', port: '80', action: 'Allow' },
        { id: 3, source: 'Any', destination: 'Any', port: 'Any', action: 'Block' },
    ])

    const [newRule, setNewRule] = useState<Omit<Rule, 'id'>>({
        source: '',
        destination: '',
        port: '',
        action: 'Block',
    })

    const handleAddRule = () => {
        setRules([...rules, { ...newRule, id: rules.length + 1 }])
        setNewRule({ source: '', destination: '', port: '', action: 'Block' })
    }

    return (
        <Card className="bg-gray-800 border-green-500">
            <CardHeader>
                <CardTitle className="text-green-400">Firewall Configuration</CardTitle>
                <CardDescription className="text-gray-400">Manage firewall rules</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-5 gap-2 mb-4">
                    <Input
                        placeholder="Source"
                        value={newRule.source}
                        onChange={(e) => setNewRule({ ...newRule, source: e.target.value })}
                        className="bg-gray-700 text-green-400 border-green-500"
                    />
                    <Input
                        placeholder="Destination"
                        value={newRule.destination}
                        onChange={(e) => setNewRule({ ...newRule, destination: e.target.value })}
                        className="bg-gray-700 text-green-400 border-green-500"
                    />
                    <Input
                        placeholder="Port"
                        value={newRule.port}
                        onChange={(e) => setNewRule({ ...newRule, port: e.target.value })}
                        className="bg-gray-700 text-green-400 border-green-500"
                    />
                    <select
                        value={newRule.action}
                        onChange={(e) => setNewRule({ ...newRule, action: e.target.value })}
                        className="bg-gray-700 text-green-400 border-green-500 rounded"
                    >
                        <option value="Allow">Allow</option>
                        <option value="Block">Block</option>
                    </select>
                    <Button onClick={handleAddRule}>Add Rule</Button>
                </div>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="text-green-400">Source</TableHead>
                            <TableHead className="text-green-400">Destination</TableHead>
                            <TableHead className="text-green-400">Port</TableHead>
                            <TableHead className="text-green-400">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {rules.map((rule) => (
                            <TableRow key={rule.id}>
                                <TableCell>{rule.source}</TableCell>
                                <TableCell>{rule.destination}</TableCell>
                                <TableCell>{rule.port}</TableCell>
                                <TableCell>{rule.action}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    )
}

