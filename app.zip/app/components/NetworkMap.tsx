'use client'
import React from 'react';
import { useRef, useEffect } from 'react'
import { useSimulation } from '../contexts/SimulationContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"

export default function NetworkMap() {
    const canvasRef = useRef<HTMLCanvasElement>(null)
    const { isUnderAttack, mitigationLevel, pfSenseEnabled } = useSimulation()

    useEffect(() => {
        const canvas = canvasRef.current
        if (!canvas) return

        const ctx = canvas.getContext('2d')
        if (!ctx) return

        const width = canvas.width
        const height = canvas.height

        const drawNode = (x: number, y: number, label: string, isTarget: boolean = false) => {
            ctx.beginPath()
            ctx.arc(x, y, 20, 0, Math.PI * 2)
            ctx.fillStyle = isTarget ? (isUnderAttack ? 'red' : 'green') : 'blue'
            ctx.fill()
            ctx.fillStyle = 'white'
            ctx.font = '12px Arial'
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.fillText(label, x, y)
        }

        const drawEdge = (x1: number, y1: number, x2: number, y2: number) => {
            ctx.beginPath()
            ctx.moveTo(x1, y1)
            ctx.lineTo(x2, y2)
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)'
            ctx.stroke()
        }

        const drawPacket = (x: number, y: number, targetX: number, targetY: number, isAttack: boolean) => {
            const dx = targetX - x
            const dy = targetY - y
            const distance = Math.sqrt(dx * dx + dy * dy)
            const ratio = 5 / distance
            const moveX = dx * ratio
            const moveY = dy * ratio

            ctx.beginPath()
            ctx.arc(x + moveX, y + moveY, 3, 0, Math.PI * 2)
            ctx.fillStyle = isAttack ? 'red' : 'green'
            ctx.fill()
        }

        const drawFirewall = (x: number, y: number) => {
            ctx.fillStyle = 'orange'
            ctx.fillRect(x - 25, y - 25, 50, 50)
            ctx.fillStyle = 'white'
            ctx.font = '12px Arial'
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.fillText('pfSense', x, y)
        }

        const animate = () => {
            ctx.clearRect(0, 0, width, height)

            // Draw edges
            drawEdge(width / 2, height / 2, width / 4, height / 4)
            drawEdge(width / 2, height / 2, 3 * width / 4, height / 4)
            drawEdge(width / 2, height / 2, width / 4, 3 * height / 4)
            drawEdge(width / 2, height / 2, 3 * width / 4, 3 * height / 4)

            // Draw nodes
            drawNode(width / 2, height / 2, 'Target', true)
            drawNode(width / 4, height / 4, 'Node 1')
            drawNode(3 * width / 4, height / 4, 'Node 2')
            drawNode(width / 4, 3 * height / 4, 'Node 3')
            drawNode(3 * width / 4, 3 * height / 4, 'Node 4')

            // Draw pfSense firewall if enabled
            if (pfSenseEnabled) {
                drawFirewall(width / 2, height / 4)
            }

            // Draw packets
            if (Math.random() < 0.3) {
                drawPacket(width / 4, height / 4, width / 2, height / 2, false)
            }
            if (Math.random() < 0.3) {
                drawPacket(3 * width / 4, height / 4, width / 2, height / 2, false)
            }
            if (Math.random() < 0.3) {
                drawPacket(width / 4, 3 * height / 4, width / 2, height / 2, false)
            }
            if (Math.random() < 0.3) {
                drawPacket(3 * width / 4, 3 * height / 4, width / 2, height / 2, false)
            }

            if (isUnderAttack) {
                for (let i = 0; i < 10; i++) {
                    if (Math.random() < 0.5 * (1 - mitigationLevel / 100)) {
                        const angle = Math.random() * Math.PI * 2
                        const radius = Math.min(width, height) / 2
                        const startX = width / 2 + Math.cos(angle) * radius
                        const startY = height / 2 + Math.sin(angle) * radius

                        if (pfSenseEnabled) {
                            // Draw packets to pfSense firewall
                            drawPacket(startX, startY, width / 2, height / 4, true)
                        } else {
                            // Draw packets directly to target
                            drawPacket(startX, startY, width / 2, height / 2, true)
                        }
                    }
                }
            }

            requestAnimationFrame(animate)
        }

        animate()
    }, [isUnderAttack, mitigationLevel, pfSenseEnabled])

    return (
        <Card>
            <CardHeader>
                <CardTitle>Network Map</CardTitle>
                <CardDescription>Real-time visualization of network traffic with pfSense firewall</CardDescription>
            </CardHeader>
            <CardContent>
                <canvas ref={canvasRef} width={600} height={400} className="w-full h-auto" />
            </CardContent>
        </Card>
    )
}

