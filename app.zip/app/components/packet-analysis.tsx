import React from 'react';
import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"

interface Packet {
    id: number
    source: string
    destination: string
    protocol: string
    size: number
    flags: string
}

interface PacketAnalysisProps {
    isUnderAttack: boolean
    mitigationActive: boolean
}

export default function PacketAnalysis({ isUnderAttack, mitigationActive }: PacketAnalysisProps) {
    const [packets, setPackets] = useState<Packet[]>([])

    useEffect(() => {
        const generatePacket = (id: number): Packet => ({
            id,
            source: `192.168.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
            destination: '10.0.0.1',
            protocol: Math.random() > 0.5 ? 'TCP' : 'UDP',
            size: Math.floor(Math.random() * 1000) + 64,
            flags: isUnderAttack ? 'SYN' : Math.random() > 0.5 ? 'ACK' : 'PSH',
        })

        const interval = setInterval(() => {
            setPackets(prevPackets => {
                const newPackets = [...prevPackets, generatePacket(prevPackets.length)]
                return newPackets.slice(-10)  // Keep only the last 10 packets
            })
        }, isUnderAttack ? 200 : 1000)

        return () => clearInterval(interval)
    }, [isUnderAttack])

    return (
        <Card className="bg-gray-800 border-green-500">
            <CardHeader>
                <CardTitle className="text-green-400">Packet Analysis</CardTitle>
                <CardDescription className="text-gray-400">Real-time packet inspection</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="text-green-400">ID</TableHead>
                            <TableHead className="text-green-400">Source</TableHead>
                            <TableHead className="text-green-400">Destination</TableHead>
                            <TableHead className="text-green-400">Protocol</TableHead>
                            <TableHead className="text-green-400">Size</TableHead>
                            <TableHead className="text-green-400">Flags</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {packets.map((packet) => (
                            <TableRow key={packet.id} className={mitigationActive && isUnderAttack ? 'opacity-50' : ''}>
                                <TableCell>{packet.id}</TableCell>
                                <TableCell>{packet.source}</TableCell>
                                <TableCell>{packet.destination}</TableCell>
                                <TableCell>{packet.protocol}</TableCell>
                                <TableCell>{packet.size}</TableCell>
                                <TableCell>{packet.flags}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    )
}

