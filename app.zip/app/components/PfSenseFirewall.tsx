'use client'
import React from 'react';
import { useState, useEffect } from 'react'
import { useSimulation } from '../contexts/SimulationContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"
import { Button } from "./ui/button"
import { Input } from "./ui/input"

interface FirewallRule {
    id: number
    source: string
    destination: string
    port: string
    action: 'Allow' | 'Block'
}

interface BlockedIP {
    ip: string
    timestamp: number
}

export default function PfSenseFirewall() {
    const { isUnderAttack, addAlert } = useSimulation()
    const [rules, setRules] = useState<FirewallRule[]>([
        { id: 1, source: 'Any', destination: '10.0.0.1', port: '80', action: 'Allow' },
        { id: 2, source: 'Any', destination: 'Any', port: 'Any', action: 'Block' },
    ])
    const [blockedIPs, setBlockedIPs] = useState<BlockedIP[]>([])
    const [newRule, setNewRule] = useState<Omit<FirewallRule, 'id'>>({
        source: '',
        destination: '',
        port: '',
        action: 'Block',
    })

    useEffect(() => {
        if (isUnderAttack) {
            const interval = setInterval(() => {
                const randomIP = `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`
                setBlockedIPs(prev => [...prev.slice(-9), { ip: randomIP, timestamp: Date.now() }])
                addAlert({
                    id: Date.now(),
                    timestamp: Date.now(),
                    type: 'warning',
                    message: `pfSense: Blocked suspicious IP ${randomIP}`,
                })
            }, 5000)
            return () => clearInterval(interval)
        }
    }, [isUnderAttack, addAlert])

    const handleAddRule = () => {
        setRules(prev => [...prev, { ...newRule, id: prev.length + 1 }])
        setNewRule({ source: '', destination: '', port: '', action: 'Block' })
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>pfSense Firewall</CardTitle>
                <CardDescription>Configure and monitor pfSense firewall rules and blocked IPs</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    <div>
                        <h3 className="text-lg font-semibold mb-2">Firewall Rules</h3>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Source</TableHead>
                                    <TableHead>Destination</TableHead>
                                    <TableHead>Port</TableHead>
                                    <TableHead>Action</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {rules.map((rule) => (
                                    <TableRow key={rule.id}>
                                        <TableCell>{rule.source}</TableCell>
                                        <TableCell>{rule.destination}</TableCell>
                                        <TableCell>{rule.port}</TableCell>
                                        <TableCell>{rule.action}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                    <div className="flex space-x-2">
                        <Input
                            placeholder="Source"
                            value={newRule.source}
                            onChange={(e) => setNewRule({ ...newRule, source: e.target.value })}
                        />
                        <Input
                            placeholder="Destination"
                            value={newRule.destination}
                            onChange={(e) => setNewRule({ ...newRule, destination: e.target.value })}
                        />
                        <Input
                            placeholder="Port"
                            value={newRule.port}
                            onChange={(e) => setNewRule({ ...newRule, port: e.target.value })}
                        />
                        <select
                            value={newRule.action}
                            onChange={(e) => setNewRule({ ...newRule, action: e.target.value as 'Allow' | 'Block' })}
                            className="border rounded px-2 py-1"
                        >
                            <option value="Allow">Allow</option>
                            <option value="Block">Block</option>
                        </select>
                        <Button onClick={handleAddRule}>Add Rule</Button>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold mb-2">Recently Blocked IPs</h3>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>IP Address</TableHead>
                                    <TableHead>Timestamp</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {blockedIPs.map((ip, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{ip.ip}</TableCell>
                                        <TableCell>{new Date(ip.timestamp).toLocaleString()}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

