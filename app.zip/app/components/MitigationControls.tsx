'use client';
import React from 'react';
import { useSimulation, AttackType, MitigationTechnique } from '../contexts/SimulationContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';

export default function MitigationControls() {
    const {
        isUnderAttack,
        setIsUnderAttack,
        attackType,
        setAttackType,
        mitigationLevel,
        setMitigationLevel,
        activeMitigationTechniques,
        setActiveMitigationTechniques,
        pfSenseEnabled,
        setPfSenseEnabled,
    } = useSimulation();

    const attackTypes: AttackType[] = ['SYN Flood', 'UDP Flood', 'HTTP Flood', 'Slowloris', 'DNS Amplification'];

    const mitigationTechniques: MitigationTechnique[] = [
        'Rate Limiting',
        'IP Blocking',
        'CAPTCHA Challenge',
        'Traffic Shaping',
        'Anomaly Detection',
        'Deep Packet Inspection',
        'Blackholing',
        'Sinkholing',
        'pfSense Firewall',
    ];

    // Toggle technique function
    const toggleTechnique = (technique: MitigationTechnique) => {
        setActiveMitigationTechniques((prev: MitigationTechnique[]) => {
            return prev.includes(technique)
                ? prev.filter((t) => t !== technique) // Remove the technique
                : [...prev, technique]; // Add the technique
        });
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Mitigation Controls</CardTitle>
                <CardDescription>Configure and activate advanced DDoS mitigation measures</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <span>Simulation Status:</span>
                    <Button
                        onClick={() => setIsUnderAttack(!isUnderAttack)}
                        variant={isUnderAttack ? 'destructive' : 'default'}
                    >
                        {isUnderAttack ? 'Stop Attack' : 'Start Attack'}
                    </Button>
                </div>
                <div className="space-y-2">
                    <label htmlFor="attack-type" className="font-medium">
                        Attack Type:
                    </label>
                    <Select value={attackType} onValueChange={(value: AttackType) => setAttackType(value)}>
                        <SelectTrigger id="attack-type">
                            <SelectValue placeholder="Select attack type" />
                        </SelectTrigger>
                        <SelectContent>
                            {attackTypes.map((type) => (
                                <SelectItem key={type} value={type}>
                                    {type}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <div className="flex justify-between">
                        <span>Mitigation Level:</span>
                        <span>{mitigationLevel}%</span>
                    </div>
                    <Slider
                        value={[mitigationLevel]}
                        onValueChange={([value]) => setMitigationLevel(value)}
                        max={100}
                        step={1}
                    />
                </div>
                <div className="space-y-2">
                    <h4 className="font-semibold">Active Mitigation Techniques:</h4>
                    {mitigationTechniques.map((technique) => (
                        <div key={technique} className="flex items-center space-x-2">
                            <input
                                type="checkbox"
                                id={technique}
                                checked={activeMitigationTechniques.includes(technique)}
                                onChange={() => toggleTechnique(technique)}
                            />
                            <label htmlFor={technique}>{technique}</label>
                        </div>
                    ))}
                </div>
                <div className="flex items-center space-x-2">
                    <Switch id="pfSense" checked={pfSenseEnabled} onCheckedChange={setPfSenseEnabled} />
                    <label htmlFor="pfSense">Enable pfSense Firewall</label>
                </div>
            </CardContent>
        </Card>
    );
}
