'use client'

import React from 'react';
import { useSimulation } from '../contexts/SimulationContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { ScrollArea } from "./ui/scroll-area"

export default function AlertLog() {
    const { alerts } = useSimulation()

    return (
        <Card>
            <CardHeader>
                <CardTitle>Alert Log</CardTitle>
                <CardDescription>Real-time security alerts and events</CardDescription>
            </CardHeader>
            <CardContent>
                <ScrollArea className="h-[400px]">
                    {alerts.map(alert => (
                        <div key={alert.id} className={`p-2 mb-2 rounded ${alert.type === 'danger' ? 'bg-red-900' :
                                alert.type === 'warning' ? 'bg-yellow-900' :
                                    'bg-blue-900'
                            }`}>
                            <div className="text-sm font-semibold">
                                {new Date(alert.timestamp).toLocaleString()}
                            </div>
                            <div>{alert.message}</div>
                        </div>
                    ))}
                </ScrollArea>
            </CardContent>
        </Card>
    )
}

