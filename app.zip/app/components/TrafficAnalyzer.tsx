'use client'
import React from 'react';
import { useSimulation } from '../contexts/SimulationContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
type MitigationTechnique = string;

export default function TrafficAnalyzer() {
    const { trafficData } = useSimulation();

    return (
        <Card>
            <CardHeader>
                <CardTitle>Traffic Analysis</CardTitle>
                <CardDescription>Real-time traffic volume visualization</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={trafficData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                            dataKey="timestamp"
                            tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()}
                        />
                        <YAxis />
                        <Tooltip
                            labelFormatter={(timestamp) => new Date(timestamp).toLocaleString()}
                            formatter={(value, name) => {
                                // Ensure `value` is a number before calling `.toFixed(2)`
                                if (typeof value === 'number') {
                                    return [`${value.toFixed(2)}`, name === 'normalTraffic' ? 'Normal Traffic' : 'Attack Traffic'];
                                }
                                return [`${value}`, name]; // Fallback for unexpected value types
                            }}
                        />
                        <Legend />
                        <Line type="monotone" dataKey="normalTraffic" stroke="#8884d8" name="Normal Traffic" />
                        <Line type="monotone" dataKey="attackTraffic" stroke="#82ca9d" name="Attack Traffic" />
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}
