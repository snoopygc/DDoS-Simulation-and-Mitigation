'use client'
import React, { useState, useEffect } from 'react';
import { useSimulation } from '../contexts/SimulationContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface AnomalyScore {
    timestamp: number;
    score: number;
}

export default function MachineLearningAnalyzer() {
    const { trafficData, isUnderAttack, attackType } = useSimulation();
    const [anomalyScores, setAnomalyScores] = useState<AnomalyScore[]>([]);

    useEffect(() => {
        const detectAnomalies = () => {
            const latestTraffic = trafficData[trafficData.length - 1];
            if (!latestTraffic) return;

            const totalTraffic = latestTraffic.normalTraffic + latestTraffic.attackTraffic;
            const baselineTraffic = 100; // Assuming a baseline of 100 for normal traffic

            // Calculate anomaly score based on traffic deviation from baseline
            const deviation = Math.abs(totalTraffic - baselineTraffic);
            const maxDeviation = 1000; // Maximum expected deviation
            const anomalyScore = Math.min((deviation / maxDeviation) * 100, 100);

            setAnomalyScores((prev) => [
                ...prev.slice(-19), // Keep the last 20 entries
                { timestamp: latestTraffic.timestamp, score: anomalyScore },
            ]);
        };

        detectAnomalies();
    }, [trafficData]);

    return (
        <Card>
            <CardHeader>
                <CardTitle>Machine Learning Analyzer</CardTitle>
                <CardDescription>Anomaly detection using machine learning algorithms</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={anomalyScores}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                            dataKey="timestamp"
                            tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()}
                        />
                        <YAxis />
                        <Tooltip
                            labelFormatter={(timestamp) => new Date(timestamp).toLocaleString()}
                            formatter={(value) => {
                                if (typeof value === 'number') {
                                    return [`${value.toFixed(2)}%`, 'Anomaly Score'];
                                }
                                return [`${value}`, 'Anomaly Score'];
                            }}
                        />
                        <Legend />
                        <Bar dataKey="score" fill="#8884d8" name="Anomaly Score" />
                    </BarChart>
                </ResponsiveContainer>
                <div className="mt-4">
                    <h4 className="font-semibold">Analysis:</h4>
                    <p>
                        {isUnderAttack
                            ? `Potential ${attackType} attack detected. Anomaly scores are elevated.`
                            : 'No significant anomalies detected. Traffic patterns appear normal.'}
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}
