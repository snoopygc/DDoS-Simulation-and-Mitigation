'use client'

import React from 'react';
import { useState } from 'react'
import NetworkMap from './NetworkMap'
import TrafficAnalyzer from './TrafficAnalyzer'
import PacketInspector from './PacketInspector'
import MitigationControls from './MitigationControls'
import AlertLog from './AlertLog'
import MachineLearningAnalyzer from './MachineLearningAnalyzer'
import PfSenseFirewall from './PfSenseFirewall'
import { SimulationProvider } from '../contexts/SimulationContext'

export default function Dashboard() {
    const [activeTab, setActiveTab] = useState('overview')

    return (
        <SimulationProvider>
            <div className="container mx-auto px-4 py-8">
                <h1 className="text-4xl font-bold mb-8 text-center text-blue-400">Advanced DDoS Simulation and Mitigation Platform</h1>
                <div className="flex flex-wrap -mx-2 mb-8">
                    <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')}>Overview</TabButton>
                    <TabButton active={activeTab === 'traffic'} onClick={() => setActiveTab('traffic')}>Traffic Analysis</TabButton>
                    <TabButton active={activeTab === 'packets'} onClick={() => setActiveTab('packets')}>Packet Inspection</TabButton>
                    <TabButton active={activeTab === 'mitigation'} onClick={() => setActiveTab('mitigation')}>Mitigation Controls</TabButton>
                    <TabButton active={activeTab === 'ml'} onClick={() => setActiveTab('ml')}>ML Analysis</TabButton>
                    <TabButton active={activeTab === 'pfsense'} onClick={() => setActiveTab('pfsense')}>pfSense Firewall</TabButton>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        {activeTab === 'overview' && <NetworkMap />}
                        {activeTab === 'traffic' && <TrafficAnalyzer />}
                        {activeTab === 'packets' && <PacketInspector />}
                        {activeTab === 'mitigation' && <MitigationControls />}
                        {activeTab === 'ml' && <MachineLearningAnalyzer />}
                        {activeTab === 'pfsense' && <PfSenseFirewall />}
                    </div>
                    <div>
                        <AlertLog />
                    </div>
                </div>
            </div>
        </SimulationProvider>
    )
}

function TabButton({ children, active, onClick }: { children: React.ReactNode, active: boolean, onClick: () => void }) {
    return (
        <button
            className={`px-4 py-2 rounded-t-lg font-semibold ${active ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'}`}
            onClick={onClick}
        >
            {children}
        </button>
    )
}