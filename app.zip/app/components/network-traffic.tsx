import React from 'react';
import { useEffect, useRef } from 'react'

interface NetworkTrafficProps {
    isUnderAttack: boolean
    mitigationActive: boolean
}

export default function NetworkTraffic({ isUnderAttack, mitigationActive }: NetworkTrafficProps) {
    const canvasRef = useRef<HTMLCanvasElement>(null)

    useEffect(() => {
        const canvas = canvasRef.current
        if (!canvas) return

        const ctx = canvas.getContext('2d')
        if (!ctx) return

        let animationFrameId: number

        const draw = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height)

            // Draw network lines
            ctx.strokeStyle = '#1a1a1a'
            for (let i = 0; i < 10; i++) {
                ctx.beginPath()
                ctx.moveTo(0, i * 30)
                ctx.lineTo(canvas.width, i * 30)
                ctx.stroke()
            }

            // Draw packets
            const packetCount = isUnderAttack ? 50 : 10
            for (let i = 0; i < packetCount; i++) {
                const x = Math.random() * canvas.width
                const y = Math.random() * canvas.height
                const size = isUnderAttack ? Math.random() * 8 + 2 : Math.random() * 4 + 2

                ctx.fillStyle = mitigationActive ? '#22c55e' : isUnderAttack ? '#ef4444' : '#3b82f6'
                ctx.beginPath()
                ctx.arc(x, y, size, 0, Math.PI * 2)
                ctx.fill()
            }

            animationFrameId = requestAnimationFrame(draw)
        }

        draw()

        return () => {
            cancelAnimationFrame(animationFrameId)
        }
    }, [isUnderAttack, mitigationActive])

    return (
        <canvas
            ref={canvasRef}
            width={400}
            height={200}
            className="w-full h-48 bg-gray-900 border border-gray-700 rounded"
        />
    )
}

