'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

interface SimulationContextType {
    isUnderAttack: boolean;
    setIsUnderAttack: (value: boolean) => void;
    attackType: AttackType;
    setAttackType: (value: AttackType) => void;
    mitigationLevel: number;
    setMitigationLevel: (value: number) => void;
    activeMitigationTechniques: MitigationTechnique[];
    setActiveMitigationTechniques: React.Dispatch<React.SetStateAction<MitigationTechnique[]>>;
    pfSenseEnabled: boolean;
    setPfSenseEnabled: (value: boolean) => void;
    trafficData: TrafficData[];
    addTrafficData: (data: TrafficData) => void;
    alerts: Alert[];
    addAlert: (alert: Alert) => void;
}

export type AttackType = 
    | 'SYN Flood' 
    | 'UDP Flood' 
    | 'HTTP Flood' 
    | 'Slowloris' 
    | 'DNS Amplification';

export type MitigationTechnique = 
    | 'Rate Limiting' 
    | 'IP Blocking' 
    | 'CAPTCHA Challenge' 
    | 'Traffic Shaping' 
    | 'Anomaly Detection' 
    | 'Deep Packet Inspection' 
    | 'Blackholing' 
    | 'Sinkholing' 
    | 'pfSense Firewall';

interface TrafficData {
    timestamp: number;
    normalTraffic: number;
    attackTraffic: number;
}

interface Alert {
    id: number;
    timestamp: number;
    type: 'info' | 'warning' | 'danger';
    message: string;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export function SimulationProvider({ children }: { children: React.ReactNode }) {
    const [isUnderAttack, setIsUnderAttack] = useState(false);
    const [attackType, setAttackType] = useState<AttackType>('SYN Flood');
    const [mitigationLevel, setMitigationLevel] = useState(0);
    const [activeMitigationTechniques, setActiveMitigationTechniques] = useState<MitigationTechnique[]>([]);
    const [pfSenseEnabled, setPfSenseEnabled] = useState(false);
    const [trafficData, setTrafficData] = useState<TrafficData[]>([]);
    const [alerts, setAlerts] = useState<Alert[]>([]);

    const addTrafficData = (data: TrafficData) => {
        setTrafficData((prev) => [...prev.slice(-59), data]);
    };

    const addAlert = (alert: Alert) => {
        setAlerts((prev) => [alert, ...prev.slice(0, 99)]);
    };

    useEffect(() => {
        const interval = setInterval(() => {
            const timestamp = Date.now();
            const normalTraffic = Math.random() * 100;
            let attackTraffic = 0;

            if (isUnderAttack) {
                switch (attackType) {
                    case 'SYN Flood':
                        attackTraffic = Math.random() * 500;
                        break;
                    case 'UDP Flood':
                        attackTraffic = Math.random() * 700;
                        break;
                    case 'HTTP Flood':
                        attackTraffic = Math.random() * 600;
                        break;
                    case 'Slowloris':
                        attackTraffic = Math.random() * 300;
                        break;
                    case 'DNS Amplification':
                        attackTraffic = Math.random() * 800;
                        break;
                }

                // Apply mitigation techniques
                const mitigationEffectiveness = activeMitigationTechniques.length * 0.1 + mitigationLevel / 100;
                attackTraffic *= Math.max(0, 1 - mitigationEffectiveness);

                // Apply pfSense mitigation if enabled
                if (pfSenseEnabled) {
                    attackTraffic *= 0.5; // Reduce attack traffic by 50% when pfSense is enabled
                }
            }

            addTrafficData({ timestamp, normalTraffic, attackTraffic });

            if (isUnderAttack && Math.random() < 0.1) {
                addAlert({
                    id: timestamp,
                    timestamp,
                    type: 'danger',
                    message: `High ${attackType} traffic detected from ${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
                });
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [isUnderAttack, attackType, mitigationLevel, activeMitigationTechniques, pfSenseEnabled]);

    return (
        <SimulationContext.Provider
            value={{
                isUnderAttack,
                setIsUnderAttack,
                attackType,
                setAttackType,
                mitigationLevel,
                setMitigationLevel,
                activeMitigationTechniques,
                setActiveMitigationTechniques,
                pfSenseEnabled,
                setPfSenseEnabled,
                trafficData,
                addTrafficData,
                alerts,
                addAlert,
            }}
        >
            {children}
        </SimulationContext.Provider>
    );
}

export function useSimulation() {
    const context = useContext(SimulationContext);
    if (context === undefined) {
        throw new Error('useSimulation must be used within a SimulationProvider');
    }
    return context;
}
