import React from 'react';
import Dashboard from './components/Dashboard'

export default function Home() {
    return (
        <main className="min-h-screen bg-gray-900 text-gray-100">
            <Dashboard />
        </main>
    )
}

